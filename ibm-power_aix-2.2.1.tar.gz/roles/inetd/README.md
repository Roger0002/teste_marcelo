# Ansible Role: inetd
The [IBM Power Systems AIX](../../README.md) collection provides an [Ansible role](https://docs.ansible.com/ansible/latest/user_guide/playbooks_reuse_roles.html), referred to as `inetd`, which can be used to enable or disable inetd services, including ftpd, rlogind, rexecd, rshd, telnetd.

For guides and reference, see the [Docs Site](https://ibm.github.io/ansible-power-aix/roles.html).

## Copyright
© Copyright IBM Corporation 2020
