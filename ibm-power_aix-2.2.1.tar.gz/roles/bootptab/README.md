# Ansible Role: bootptab
The [IBM Power Systems AIX](../../README.md) collection provides an [Ansible role](https://docs.ansible.com/ansible/latest/user_guide/playbooks_reuse_roles.html), referred to as `bootptab`, which can be used to add or remove entries to the bootptab file.

For guides and reference, see the [Docs Site](https://ibm.github.io/ansible-power-aix/roles.html).

## Copyright
© Copyright IBM Corporation 2020
